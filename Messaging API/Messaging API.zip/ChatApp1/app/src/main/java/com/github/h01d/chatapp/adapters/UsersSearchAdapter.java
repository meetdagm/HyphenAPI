package com.github.h01d.chatapp.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.h01d.chatapp.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class UsersSearchAdapter extends RecyclerView.Adapter<UsersSearchAdapter.SearchViewHolder> {
    Context context;
    ArrayList<String> userNameList;
    ArrayList<String> profileImageList;
    ArrayList<String> userStatusList;
//    ArrayList<String> userNameList;
//    ArrayList<String> profilePicList;

    class SearchViewHolder extends RecyclerView.ViewHolder {
        ImageView profileImage;
        TextView userName, userStatus;

        public SearchViewHolder(View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.user_name);
            profileImage = itemView.findViewById(R.id.user_image);
            userStatus = itemView.findViewById(R.id.user_status);
        }
    }

    public UsersSearchAdapter(Context context, ArrayList<String> profileImageList, ArrayList<String> userNameList, ArrayList<String> userStatusList) {
        this.context = context;
        this.profileImageList = profileImageList;
        this.userNameList = userNameList;
        this.userStatusList = userStatusList;
    }

    @Override
    public UsersSearchAdapter.SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.user_search, parent, false);
        return new UsersSearchAdapter.SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchViewHolder holder, int position) {
        holder.userName.setText(userNameList.get(position));
        holder.userStatus.setText(userStatusList.get(position));
//        Glide.with(context).load(profilePicList.get(position)).asBitmap().placeholder(R.mipmap.ic_launcher_round).into(holder.profileImage);

        final String image = profileImageList.get(position);

        if (!image.equals("default")) {
            Picasso.with(context)
                    .load(image)
                    .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()))
                    .centerCrop()
                    .networkPolicy(NetworkPolicy.OFFLINE)
                    .placeholder(R.drawable.user)
                    .into(holder.profileImage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {
                            Picasso.with(context)
                                    .load(image)
                                    .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()))
                                    .centerCrop()
                                    .placeholder(R.drawable.user)
                                    .error(R.drawable.user)
                                    .into(holder.profileImage);
                        }
                    });
        } else {
            holder.profileImage.setImageResource(R.drawable.hyphen_profile_picture_placeholder);
        }


        holder.userName.setOnClickListener(v -> Toast.makeText(context, "Full Name Clicked", Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return userNameList.size();
    }
}
