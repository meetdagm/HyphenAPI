package com.github.h01d.chatapp.activities;

import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.github.h01d.chatapp.R;
import com.github.h01d.chatapp.adapters.UsersSearchAdapter;
import com.github.h01d.chatapp.holders.UserHolder;
import com.github.h01d.chatapp.holders.UserHolderSearch;
import com.github.h01d.chatapp.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UsersActivity extends AppCompatActivity {
    private final String TAG = "CA/UsersActivity";

    private FirebaseRecyclerAdapter adapter;
    private boolean isSearching = false;

    EditText search_edit_text;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    FirebaseUser firebaseUser;
    ArrayList<String> userNameList;
    ArrayList<String> profileImageList;
    ArrayList<String> userStatusList;
    UsersSearchAdapter searchAdapter;
    //users_list_search

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);


        // region SOL SEARCH
        search_edit_text = findViewById(R.id.users_list_search);
        recyclerView = findViewById(R.id.users_recycler);

        databaseReference = FirebaseDatabase.getInstance().getReference();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        /*
         * Create a array list for each node you want to use
         * */

        userNameList = new ArrayList<>();
        profileImageList = new ArrayList<>();
        userStatusList = new ArrayList<>();

        search_edit_text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    setAdapter(s.toString());
//                    isSearching = true;
                } else {
//                    /*
//                     * Clear the list when editText is empty
//                     * */
////                    fullNameList.clear();
//                    userNameList.clear();
////                    profilePicList.clear();
//                    recyclerView.removeAllViews();
////                    listAllUsers();
////                    isSearching = false;
                    userNameList.clear();
                    setAdapter(s.toString());
                }
            }
        });


        // endregion


        // region List All Users
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());

        RecyclerView recyclerView = findViewById(R.id.users_recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

//        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), linearLayoutManager.getOrientation());
//        recyclerView.addItemDecoration(mDividerItemDecoration);

        listAllUsers();
        // endregion
    }

    private void listAllUsers() {
        // RecyclerView related
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.println("List All Users Has Been Called");
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");


        // Initializing Users database

        DatabaseReference usersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");
        usersDatabase.keepSynced(true); // For offline use

        // Initializing adapter

        FirebaseRecyclerOptions<User> options = new FirebaseRecyclerOptions.Builder<User>().setQuery(usersDatabase.orderByChild("name"), User.class).build();

        adapter = new FirebaseRecyclerAdapter<User, UserHolderSearch>(options) {
            @Override
            protected void onBindViewHolder(final UserHolderSearch holder, int position, User model) {
                final String userid = getRef(position).getKey();

                holder.setHolder(userid);
                holder.getView().setOnClickListener(view -> {
                    Intent userProfileIntent = new Intent(UsersActivity.this, ProfileActivity.class);
                    userProfileIntent.putExtra("userid", userid);
                    startActivity(userProfileIntent);
                });
            }

            @Override
            public UserHolderSearch onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_search, parent, false);

                return new UserHolderSearch(UsersActivity.this, view, getApplicationContext());
            }
        };

        recyclerView.setAdapter(adapter);
    }


    // region SOL SEARCH
    private void setAdapter(final String searchedString) {
        databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                /*
                 * Clear the list for every new search
                 * */
//                fullNameList.clear();
                userNameList.clear();
//                profilePicList.clear();
                recyclerView.removeAllViews();

                int counter = 0;

                /*
                 * Search all users for matching searched string
                 * */
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String uid = snapshot.getKey();
                    String status = snapshot.child("status").getValue(String.class);
                    String userName = snapshot.child("name").getValue(String.class);
                    String profilePic = snapshot.child("image").getValue(String.class);

                    if (searchedString.length() > 0) {
                        if (userName.toLowerCase().contains(searchedString.toLowerCase())) {
                            userNameList.add(userName);
                            profileImageList.add(profilePic);
                            userStatusList.add(status);
                            counter++;
                        }
                    } else {
                        userNameList.add(userName);
                        profileImageList.add(profilePic);
                        userStatusList.add(status);
                        counter++;
                    }


                    if (searchedString.length() > 0) {
                        /*
                         * Get maximum of 15 searched results only
                         * */
                        if (counter == 15)
                            break;
                    } else {
                        if (counter == 50)
                            break;
                    }

                }

                searchAdapter = new UsersSearchAdapter(UsersActivity.this, profileImageList, userNameList, userStatusList);
                recyclerView.setAdapter(searchAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    // endregion


    @Override
    protected void onStart() {
        super.onStart();

//        if (!isSearching) {
        adapter.startListening();
//        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("online").setValue("true");
    }

    @Override
    protected void onPause() {
        super.onPause();

        FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("online").setValue(ServerValue.TIMESTAMP);
    }

    @Override
    protected void onStop() {
        super.onStop();

//        if (!isSearching) {
        adapter.stopListening();
//        }
    }

    @Override
    public void onBackPressed() {
        NavUtils.navigateUpFromSameTask(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
