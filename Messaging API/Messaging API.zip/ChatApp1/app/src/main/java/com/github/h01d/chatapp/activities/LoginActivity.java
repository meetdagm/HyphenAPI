package com.github.h01d.chatapp.activities;

import android.animation.Animator;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.github.h01d.chatapp.R;
import com.github.h01d.chatapp.activities.helpers.ActivityVisibilityChecker;
import com.github.h01d.chatapp.activities.helpers.AlertCreator;
import com.github.h01d.chatapp.activities.helpers.UIHelpers;
import com.github.h01d.chatapp.utils.Validator;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import top.wefor.circularanim.CircularAnim;

public class LoginActivity extends AppCompatActivity {
    private final String TAG = "CA/LoginActivity";
    private EditText loginEmail;
    private EditText loginPassword;
    private Button loginButton;
    private ProgressBar loginProgress;
    private TextView loginRegister;
    private TextView loginResendVerificationEmail;
    private TextView loginNetworkStatusIndicator;
    // This is the activity main thread Handler.
    private Handler updateUIHandler = null;

    // Message type code.
    private final static int MESSAGE_UPDATE_TEXT_CHILD_THREAD = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // activity_welcome views
        initUI();
        initEventHandlers();
        initNetworkStatusListeners();
    }

    @Override
    protected void onStart() {
        super.onStart();
        animateUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        merlin.bind();
        ActivityVisibilityChecker.activityResumed();
    }

    @Override
    protected void onPause() {
//        merlin.unbind();
        super.onPause();
        ActivityVisibilityChecker.activityPaused();
    }

    private void initUI() {
        bindUIElements();

        // region Other UI init
        UIHelpers.makeWindowTransparent(this);

        // endregion
    }

    private void bindUIElements() {
        loginEmail = findViewById(R.id.login_txt_email);
        loginPassword = findViewById(R.id.login_txt_password);
        loginButton = findViewById(R.id.login_btn_login);
        loginProgress = findViewById(R.id.login_loading_indicator);
        loginRegister = findViewById(R.id.login_lbl_register);
        loginResendVerificationEmail = findViewById(R.id.login_lbl_resend_verification_email);
        loginNetworkStatusIndicator = findViewById(R.id.login_lbl_network_status_indicator);
    }

    private void animateUI() {
        YoYo.with(Techniques.BounceInUp)
                .duration(500)
                .repeat(0)
                .playOn(findViewById(R.id.login_form_container));
    }

    private void initNetworkStatusListeners() {
        // region New Code
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            updateNetworkStatusIndicator(true);
        } else {
            updateNetworkStatusIndicator(false);
        }
        // endregion

        //region Old Code
        //        merlin = new Merlin.Builder()
        //                .withConnectableCallbacks()
        //                .withDisconnectableCallbacks()
        //                .build(this);
        //        merlin.registerConnectable(() -> {
        //            System.out.println("Network Available");
        //            NetworkStatus.setIsNetworkAvailable(true);
        //            loginNetworkStatusIndicator.setVisibility(View.VISIBLE);
        //            loginNetworkStatusIndicator.setTextColor(getResources().getColor(R.color.hyphen_success));
        ////            loginNetworkStatusIndicator.setText("Connected");
        //            YoYo.with(Techniques.SlideOutUp)
        //                    .duration(500)
        //                    .delay(2000)
        //                    .repeat(0)
        //                    .withListener(new Animator.AnimatorListener() {
        //                        @Override
        //                        public void onAnimationStart(Animator animator) {
        //
        //                        }
        //
        //                        @Override
        //                        public void onAnimationEnd(Animator animator) {
        //                            loginNetworkStatusIndicator.setVisibility(View.INVISIBLE);
        //                        }
        //
        //                        @Override
        //                        public void onAnimationCancel(Animator animator) {
        //                            loginNetworkStatusIndicator.setVisibility(View.INVISIBLE);
        //                        }
        //
        //                        @Override
        //                        public void onAnimationRepeat(Animator animator) {
        //
        //                        }
        //                    })
        //                    .playOn(findViewById(R.id.login_lbl_network_status_indicator));
        //        });
        //        merlin.registerDisconnectable(() -> {
        //            System.out.println("Network Not Available");
        //            NetworkStatus.setIsNetworkAvailable(false);
        //            loginNetworkStatusIndicator.setVisibility(View.VISIBLE);
        //            loginNetworkStatusIndicator.setTextColor(getResources().getColor(R.color.hyphen_error));
        //
        ////            loginNetworkStatusIndicator.setText("Connecting");
        //            YoYo.with(Techniques.BounceInDown)
        //                    .duration(500)
        //                    .repeat(0)
        //                    .playOn(findViewById(R.id.login_lbl_network_status_indicator));
        //        });
        // endregion
    }

    public void updateNetworkStatusIndicator(boolean isConnected) {
        if (isConnected) {
            System.out.println(" Avi");
            loginNetworkStatusIndicator.setVisibility(View.VISIBLE);
//            loginNetworkStatusIndicator.setTextColor(getResources().getColor(R.color.hyphen_success));
            loginNetworkStatusIndicator.setText("Connected");
            YoYo.with(Techniques.SlideOutUp)
                    .duration(500)
                    .delay(2000)
                    .repeat(0)
                    .withListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animator) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animator) {
                            loginNetworkStatusIndicator.setVisibility(View.INVISIBLE);
                        }

                        @Override
                        public void onAnimationCancel(Animator animator) {
                            loginNetworkStatusIndicator.setVisibility(View.INVISIBLE);
                        }

                        @Override
                        public void onAnimationRepeat(Animator animator) {

                        }
                    })
                    .playOn(findViewById(R.id.login_lbl_network_status_indicator));
        } else {
            System.out.println("Not Avi");
            loginNetworkStatusIndicator.setVisibility(View.VISIBLE);
//            loginNetworkStatusIndicator.setTextColor(getResources().getColor(R.color.hyphen_error));

            loginNetworkStatusIndicator.setText("Connecting");
            YoYo.with(Techniques.BounceInDown)
                    .duration(500)
                    .repeat(0)
                    .playOn(findViewById(R.id.login_lbl_network_status_indicator));
        }
    }

    private void changeEditTextColor(EditText e, int colorResource) {
        ColorStateList colorState = ColorStateList.valueOf(colorResource);
        e.setTextColor(colorResource);
        e.setBackgroundTintList(colorState);
    }

    private void initEventHandlers() {
        loginButton.setOnClickListener(view -> login());
        loginRegister.setOnClickListener(view -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            finish();
        });
        loginEmail.setOnKeyListener((v, keyCode, event) -> {
            System.out.println("KEY PRESSED");
            // region Set Error Style
            ColorStateList colorStateListDefault = ColorStateList.valueOf(getResources().getColor(R.color.hyphen_primary));
            loginEmail.setBackgroundTintList(colorStateListDefault);
            loginPassword.setBackgroundTintList(colorStateListDefault);
            // endregion
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!(loginEmail.getText().toString().length() == 0 || loginPassword.getText().toString().length() == 0)) {
                    loginButton.performClick();
                    return true;
                }
            }
            return false;
        });
        loginEmail.setOnFocusChangeListener((view, hasFocus) -> {
            if (hasFocus) {
                changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_primary));
            }
        });
        loginPassword.setOnKeyListener((v, keyCode, event) -> {
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!(loginEmail.getText().toString().length() == 0 || loginPassword.getText().toString().length() == 0)) {
                    loginButton.performClick();
                    return true;
                }
            }
            return false;
        });
        loginPassword.setOnFocusChangeListener((view, hasFocus) -> {
            if (hasFocus) {
                changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_primary));
            }
        });
    }

    private void login() {
        loginButton.setClickable(false);
        loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_inactive));

        loginEmail.clearFocus();
        loginPassword.clearFocus();

        // Hiding the soft keyboard
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(loginPassword.getWindowToken(), 0);

        if (loginEmail.getText().length() == 0 || loginPassword.getText().length() == 0) {
            AlertCreator.showErrorAlert(this, "Incomplete!", "Please fill in your credentials in order to login.");
            YoYo.with(Techniques.Shake)
                    .duration(700)
                    .repeat(0)
                    .playOn(findViewById(R.id.login_form_container));

            // region Set Error Style
            if (loginEmail.getText().length() == 0 && loginPassword.getText().length() == 0) {
                changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_error));
                changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_error));
            } else if (loginEmail.getText().length() == 0 && loginPassword.getText().length() > 0) {
                changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_error));
                changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_primary));
            } else if (loginEmail.getText().length() > 0 && loginPassword.getText().length() == 0) {
                if (!Validator.isValidEmail(loginEmail.getText().toString())) {
                    changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_error));
                    changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_error));
                } else {
                    changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_primary));
                    changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_error));
                }
            }

            // endregion

            loginProgress.setVisibility(View.INVISIBLE);
            loginButton.setClickable(true);
            loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
        } else if (!Validator.isValidEmail(loginEmail.getText().toString())) {
            AlertCreator.showErrorAlert(this, "Invalid Email!", "You've entered a badly formatted email address.");
            YoYo.with(Techniques.Shake)
                    .duration(700)
                    .repeat(0)
                    .playOn(findViewById(R.id.login_form_container));

            // region Set Error Style
            changeEditTextColor(loginEmail, getResources().getColor(R.color.hyphen_error));
            changeEditTextColor(loginPassword, getResources().getColor(R.color.hyphen_primary));
            // endregion

            loginProgress.setVisibility(View.INVISIBLE);
            loginButton.setClickable(true);
            loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
        } else {
            loginProgress.setVisibility(View.VISIBLE);

            // region Attempt To Login User Using The Provided Credentials
            FirebaseAuth.getInstance().signInWithEmailAndPassword(loginEmail.getText().toString(), loginPassword.getText().toString()).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    String token = FirebaseInstanceId.getInstance().getToken();
                    String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

                    // region Updating user device token
                    FirebaseDatabase.getInstance().getReference().child("Users").child(userId).child("token").setValue(token).addOnCompleteListener(task1 -> {
                        if (task1.isSuccessful()) {
                            loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_success));

                            if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {
                                // Show animation and start activity

                                new Handler().postDelayed(() -> CircularAnim.fullActivity(LoginActivity.this, loginButton)
                                        .colorOrImageRes(R.color.hyphen_success)
                                        .go(() -> {
                                            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                                            finish();
                                        }), 1000);
                            } else {
                                AlertCreator.showErrorAlert(LoginActivity.this, "Email Not Verified!", "Your email is not verified. You have to verify your email before you can use the app.");
                                loginResendVerificationEmail.setVisibility(View.VISIBLE);


                                loginResendVerificationEmail.setOnClickListener(view -> {
                                    AlertCreator.showSuccessAlert(LoginActivity.this, "Verification Email Sent!", "We've sent you a new verification email. Please check your email to verify your email address.");
                                    if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                                        FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                        FirebaseAuth.getInstance().signOut();
                                        loginResendVerificationEmail.setVisibility(View.GONE);
                                        loginResendVerificationEmail.setOnClickListener(null);
                                    } else {
                                        AlertCreator.showSuccessAlert(LoginActivity.this, "Error!", "Unable to send verification email. Please try again later.");
                                        loginResendVerificationEmail.setVisibility(View.GONE);
                                        loginResendVerificationEmail.setOnClickListener(null);
                                    }
                                });


                                //  FirebaseAuth.getInstance().signOut();
                                loginProgress.setVisibility(View.INVISIBLE);
                                loginButton.setClickable(true);
                                loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
                            }
                        } else {
                            AlertCreator.showErrorAlert(LoginActivity.this, "Upload Token Error!", task1.getException().getMessage());
                            loginProgress.setVisibility(View.INVISIBLE);
                            loginButton.setClickable(true);
                            loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
                        }
                    });
                    // endregion
                } else {
                    if (task.getException() instanceof FirebaseNetworkException) {
                        AlertCreator.showErrorAlert(LoginActivity.this, "SignIn Failed!", "Unable to connect. Make sure you are connected to the internet.");
                    } else {
                        AlertCreator.showErrorAlert(LoginActivity.this, "SignIn Failed!", task.getException().getMessage());
                    }
                    loginProgress.setVisibility(View.INVISIBLE);
                    loginButton.setClickable(true);
                    loginButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
                }
            });
            // endregion
        }
    }

//    @Override
//    public void onBackPressed() {
//        SlidingUpPanelLayout slidingUpPanelLayout = findViewById(R.id.welcome_sliding);
//
//        if (slidingUpPanelLayout.getPanelState() == SlidingUpPanelLayout.PanelState.EXPANDED) {
//            slidingUpPanelLayout.setPanelState(SlidingUpPanelLayout.PanelState.COLLAPSED);
//        } else {
//            super.onBackPressed();
//        }
//    }
}
