package com.github.h01d.chatapp.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.github.h01d.chatapp.R;
import com.github.h01d.chatapp.activities.ChatActivity;
import com.github.h01d.chatapp.holders.ChatHolder;
import com.github.h01d.chatapp.models.Chat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ChatFragment extends Fragment {
    private FirebaseRecyclerAdapter chatsListContainerAdapter;

    public ChatFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View chatListContainerRecyclerView = inflater.inflate(R.layout.fragment_chat, container, false);

        // region Initialize 'Chat' Database (Firebase Realtime Database Instance)
        String currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference chatDatabase = FirebaseDatabase.getInstance().getReference().child("Chat").child(currentUserID);
        // Setup database for offline use
        chatDatabase.keepSynced(true);
        // endregion

        // region Setup Recycler View That Contains Chat List
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);

        RecyclerView recyclerView = chatListContainerRecyclerView.findViewById(R.id.chat_recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(mDividerItemDecoration);
        // endregion

        // region Initializing chatsListContainerAdapter (Adapter that contains users list that the current user is chatting with)
        FirebaseRecyclerOptions<Chat> firebaseRecyclerOptions = new FirebaseRecyclerOptions
                .Builder<Chat>()
                .setQuery(
                        chatDatabase.orderByChild("timestamp"),
                        Chat.class
                )
                .build();

        chatsListContainerAdapter = new FirebaseRecyclerAdapter<Chat, ChatHolder>(firebaseRecyclerOptions) {
            @Override
            public ChatHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user, parent, false);

                return new ChatHolder(getActivity(), view, getContext());
            }

            @Override
            protected void onBindViewHolder(final ChatHolder chatHolder, int position, final Chat chatModel) {
                final String chatUserId = getRef(position).getKey();

                // Set view for a single chat instance (single list)
                chatHolder.setHolder(chatUserId, chatModel.getMessage(), chatModel.getTimestamp(), chatModel.getSeen());
                // Set on click listener for a single list item
                chatHolder.getView().setOnClickListener(view1 -> {
                    Intent chatIntent = new Intent(getContext(), ChatActivity.class);
                    chatIntent.putExtra("userID", chatUserId);
                    startActivity(chatIntent);
                });
            }

            @Override
            public void onDataChanged() {
                super.onDataChanged();


                TextView chatListContainerStatusIndicator = chatListContainerRecyclerView.findViewById(R.id.f_chat_text);

                // region If chat list is empty show 'there is no chat' text in the list
                if (chatsListContainerAdapter.getItemCount() == 0) {
                    chatListContainerStatusIndicator.setVisibility(View.VISIBLE);
                } else {
                    chatListContainerStatusIndicator.setVisibility(View.GONE);
                }
                // endregion
            }
        };

        recyclerView.setAdapter(chatsListContainerAdapter);
        // endregion
        return chatListContainerRecyclerView;
    }

    @Override
    public void onStart() {
        super.onStart();
        chatsListContainerAdapter.startListening();
        chatsListContainerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onStop() {
        super.onStop();
        chatsListContainerAdapter.stopListening();
    }
}
