package com.github.h01d.chatapp.activities;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.github.h01d.chatapp.R;
import com.github.h01d.chatapp.activities.helpers.AlertCreator;
import com.github.h01d.chatapp.activities.helpers.UIHelpers;
import com.github.h01d.chatapp.utils.Validator;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.iid.FirebaseInstanceId;
import com.tapadoo.alerter.Alerter;
import com.tapadoo.alerter.OnHideAlertListener;
import com.tapadoo.alerter.OnShowAlertListener;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private final String TAG = "CA/RegisterActivity";
    private EditText registerName;
    private EditText registerEmail;
    private EditText registerPassword;
    private Button registerButton;
    private ProgressBar registerProgress;
    private TextView registerLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initUI();
        initEventHandlers();
    }

    private void initUI() {
        bindUIElements();
        animateUI();
        // region Other UI init
        UIHelpers.makeWindowTransparent(this);
        // endregion
    }

    private void bindUIElements() {
        registerName = findViewById(R.id.register_txt_name);
        registerEmail = findViewById(R.id.register_txt_email);
        registerPassword = findViewById(R.id.register_txt_password);
        registerButton = findViewById(R.id.register_btn_register);
        registerProgress = findViewById(R.id.register_progress_register);
        registerLogin = findViewById(R.id.register_lbl_login);
    }

    private void animateUI() {
        YoYo.with(Techniques.BounceInUp)
                .duration(500)
                .repeat(0)
                .playOn(findViewById(R.id.register_form_container));
    }

    private void initEventHandlers() {
        registerButton.setOnClickListener(view -> register());
        registerLogin.setOnClickListener(view -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
        registerName.setOnKeyListener((v, keyCode, event) -> {
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!(registerName.getText().toString().length() == 0 || registerEmail.getText().toString().length() == 0 || registerPassword.getText().toString().length() == 0)) {
                    registerButton.performClick();
                    return true;
                }
            }
            return false;
        });
        registerEmail.setOnKeyListener((v, keyCode, event) -> {
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!(registerName.getText().toString().length() == 0 || registerEmail.getText().toString().length() == 0 || registerPassword.getText().toString().length() == 0)) {
                    registerButton.performClick();
                    return true;
                }
            }
            return false;
        });
        registerPassword.setOnKeyListener((v, keyCode, event) -> {
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!(registerName.getText().toString().length() == 0 || registerEmail.getText().toString().length() == 0 || registerPassword.getText().toString().length() == 0)) {
                    registerButton.performClick();
                    return true;
                }
            }
            return false;
        });
    }

    private void register() {

        registerButton.setClickable(false);
        registerButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_inactive));

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(registerButton.getWindowToken(), 0);

        if (registerName.getText().toString().length() == 0 || registerEmail.getText().toString().length() == 0 || registerPassword.getText().toString().length() == 0) {
            AlertCreator.showErrorAlert(this, "Incomplete!", "Please fill all fields in order to register.");

            registerProgress.setVisibility(View.INVISIBLE);
            registerButton.setClickable(true);
            registerButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
        } else if (!Validator.isValidEmail(registerEmail.getText().toString())) {
            AlertCreator.showErrorAlert(this, "Invalid Email!", "You've entered a badly formatted email address.");

            registerProgress.setVisibility(View.INVISIBLE);
            registerButton.setClickable(true);
            registerButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
        } else {
            registerProgress.setVisibility(View.VISIBLE);
            String userName = registerName.getText().toString();
            String userEmail = registerEmail.getText().toString();
            String userPassword = registerPassword.getText().toString();

            // region Register User
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

                    if (firebaseUser != null) {
                        String userID = firebaseUser.getUid();

                        // Map User Registration Data

                        Map map = new HashMap<>();
                        map.put("token", FirebaseInstanceId.getInstance().getToken());
                        map.put("name", userName);
                        map.put("email", userEmail);
                        map.put("status", "Hey this is " + userName);
                        map.put("image", "default");
                        map.put("cover", "default");
                        map.put("date", ServerValue.TIMESTAMP);

                        // Uploading User Registration Data To Firebase

                        FirebaseDatabase.getInstance().getReference().child("Users").child(userID).setValue(map).addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()) {
                                registerButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_success));

                                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                AlertCreator.showSuccessAlert(RegisterActivity.this, "Verify Your Email!", "We have sent you a verification email to activate your account.");
                                FirebaseAuth.getInstance().signOut();
                                registerButton.setClickable(true);
                            } else {
                                AlertCreator.showErrorAlert(RegisterActivity.this, "Error!", task1.getException().getMessage());
                            }
                        });
                    }
                } else {
                    AlertCreator.showErrorAlert(RegisterActivity.this, "Error!", task.getException().getMessage());

                    registerProgress.setVisibility(View.INVISIBLE);
                    registerButton.setClickable(true);
                    registerButton.setBackground(getResources().getDrawable(R.drawable.hyphen_button_default));
                }
            });
            // endregion
        }
    }
}
