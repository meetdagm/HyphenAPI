package com.github.h01d.chatapp.activities.helpers;

import android.app.Activity;
import android.support.annotation.DrawableRes;
import android.view.View;
import android.widget.Toast;

import com.github.h01d.chatapp.R;
import com.github.h01d.chatapp.activities.LoginActivity;
import com.tapadoo.alerter.Alerter;
import com.tapadoo.alerter.OnHideAlertListener;
import com.tapadoo.alerter.OnShowAlertListener;

public class AlertCreator {
    public static void showPromptAlert(Activity activity, String title, String message) {
        Alerter.create(activity)
                .setTitle(title)

                .setIcon(R.drawable.hyphen_success)
                .setText(message)
                .enableProgress(true)
                .setDuration(3000)
                .setProgressColorRes(R.color.hyphen_success)
                .setBackgroundColorRes(R.color.hyphen_success)
                .enableSwipeToDismiss()
                .enableIconPulse(false)
                .setOnShowListener(() -> {

                })
                .setOnHideListener(() -> {

                })
                .show();
    }

    public static void showSuccessAlert(Activity activity, String title, String message) {
        Alerter.create(activity)
                .setTitle(title)
                .setIcon(R.drawable.hyphen_success)
                .setText(message)
                .enableProgress(true)
                .setDuration(3000)
                .setProgressColorRes(R.color.hyphen_success)
                .setBackgroundColorRes(R.color.hyphen_success) // or setBackgroundColorInt(Color.CYAN)
                .enableSwipeToDismiss()
                .enableIconPulse(false)
                .setOnShowListener(() -> {

                })
                .setOnHideListener(() -> {

                })
                .show();
    }

    public static void showErrorAlert(Activity activity, String title, String message) {
        Alerter.create(activity)
                .setTitle(title)
                .setIcon(R.drawable.hyphen_error)
                .setText(message)
                .enableProgress(true)
                .setDuration(3000)
                .setProgressColorRes(R.color.hyphen_error)
                .setBackgroundColorRes(R.color.hyphen_error) // or setBackgroundColorInt(Color.CYAN)
                .enableSwipeToDismiss()
                .enableIconPulse(false)
                .setOnShowListener(() -> {

                })
                .setOnHideListener(() -> {

                })
                .show();
    }
}
