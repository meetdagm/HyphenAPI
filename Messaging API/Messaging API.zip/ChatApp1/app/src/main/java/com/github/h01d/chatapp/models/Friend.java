package com.github.h01d.chatapp.models;

public class Friend
{
    private long date;

    public Friend()
    {

    }

    public Friend(long date)
    {
        this.date = date;
    }

    public long getDate()
    {
        return date;
    }

    public void setDate(long date)
    {
        this.date = date;
    }
}
