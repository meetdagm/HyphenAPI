package com.github.h01d.chatapp.utils;

import android.text.TextUtils;
import android.util.Patterns;

public class Validator {
    public static boolean isValidEmail(CharSequence target) {
        boolean res = (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
        return res;
    }
}
