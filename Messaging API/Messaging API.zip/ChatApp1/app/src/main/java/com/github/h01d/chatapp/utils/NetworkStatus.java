package com.github.h01d.chatapp.utils;

public class NetworkStatus {
    private static boolean isNetworkAvailable = false;

    public static boolean isIsNetworkAvailable() {
        return isNetworkAvailable;
    }

    public static void setIsNetworkAvailable(boolean isNetworkAvailable) {
        NetworkStatus.isNetworkAvailable = isNetworkAvailable;
    }
}